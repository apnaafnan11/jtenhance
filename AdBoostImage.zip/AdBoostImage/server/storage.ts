import { type User, type InsertUser, type Enhancement, type InsertEnhancement } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createEnhancement(enhancement: InsertEnhancement): Promise<Enhancement>;
  getEnhancement(id: string): Promise<Enhancement | undefined>;
  updateEnhancement(id: string, updates: Partial<Enhancement>): Promise<Enhancement | undefined>;
  getRecentEnhancements(limit?: number): Promise<Enhancement[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private enhancements: Map<string, Enhancement>;

  constructor() {
    this.users = new Map();
    this.enhancements = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createEnhancement(insertEnhancement: InsertEnhancement): Promise<Enhancement> {
    const id = randomUUID();
    const enhancement: Enhancement = {
      ...insertEnhancement,
      id,
      enhancedImagePath: null,
      status: "pending",
      createdAt: new Date(),
      completedAt: null,
      errorMessage: null,
      isPublic: insertEnhancement.isPublic ?? true,
    };
    this.enhancements.set(id, enhancement);
    return enhancement;
  }

  async getEnhancement(id: string): Promise<Enhancement | undefined> {
    return this.enhancements.get(id);
  }

  async updateEnhancement(id: string, updates: Partial<Enhancement>): Promise<Enhancement | undefined> {
    const enhancement = this.enhancements.get(id);
    if (!enhancement) return undefined;

    const updated = { ...enhancement, ...updates };
    this.enhancements.set(id, updated);
    return updated;
  }

  async getRecentEnhancements(limit: number = 10): Promise<Enhancement[]> {
    return Array.from(this.enhancements.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
