import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEnhancementSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import sharp from "sharp";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Serve uploaded images
  app.use("/uploads", (req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    next();
  }, express.static("uploads"));

  // Upload image endpoint
  app.post("/api/upload", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      // Process image with Sharp to ensure it's in a standard format
      const processedImagePath = `${req.file.path}-processed.jpg`;
      await sharp(req.file.path)
        .jpeg({ quality: 90 })
        .resize(2048, 2048, { fit: "inside", withoutEnlargement: true })
        .toFile(processedImagePath);

      // Remove original file
      fs.unlinkSync(req.file.path);

      // Create enhancement record
      const enhancement = await storage.createEnhancement({
        originalImagePath: processedImagePath,
        isPublic: true,
      });

      res.json(enhancement);
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Failed to upload image" });
    }
  });

  // Enhance image endpoint
  app.post("/api/enhance/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const customSettings = req.body; // Custom enhancement settings
      const enhancement = await storage.getEnhancement(id);

      if (!enhancement) {
        return res.status(404).json({ message: "Enhancement not found" });
      }

      if (enhancement.status !== "pending") {
        return res.json(enhancement);
      }

      // Update status to processing
      await storage.updateEnhancement(id, { status: "processing" });

      // Call enhancement service with custom settings
      const enhancedImagePath = customSettings 
        ? await enhanceImageWithCustomSettings(enhancement.originalImagePath, customSettings)
        : await enhanceImageWithAI(enhancement.originalImagePath);

      // Update enhancement record
      const updatedEnhancement = await storage.updateEnhancement(id, {
        status: "completed",
        enhancedImagePath,
        completedAt: new Date(),
      });

      res.json(updatedEnhancement);
    } catch (error) {
      console.error("Enhancement error:", error);
      
      // Update status to failed
      await storage.updateEnhancement(req.params.id, {
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "Unknown error occurred",
        completedAt: new Date(),
      });

      res.status(500).json({ message: "Failed to enhance image" });
    }
  });

  // Get enhancement status
  app.get("/api/enhancement/:id", async (req, res) => {
    try {
      const enhancement = await storage.getEnhancement(req.params.id);
      if (!enhancement) {
        return res.status(404).json({ message: "Enhancement not found" });
      }
      res.json(enhancement);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enhancement" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function enhanceImageWithCustomSettings(originalImagePath: string, settings: any): Promise<string> {
  const enhancedImagePath = originalImagePath.replace("-processed.jpg", "-enhanced.jpg");
  
  let sharpInstance = sharp(originalImagePath);
  
  // Apply modulation settings
  if (settings.brightness !== 1.0 || settings.saturation !== 1.0) {
    sharpInstance = sharpInstance.modulate({
      brightness: settings.brightness || 1.0,
      saturation: settings.saturation || 1.0,
    });
  }
  
  // Apply contrast
  if (settings.contrast !== 1.0) {
    // Linear adjustment for contrast
    sharpInstance = sharpInstance.linear(settings.contrast || 1.0, 0);
  }
  
  // Apply sharpening
  if (settings.sharpening) {
    sharpInstance = sharpInstance.sharpen();
  }
  
  // Apply noise reduction (basic blur)
  if (settings.noiseReduction) {
    sharpInstance = sharpInstance.blur(0.5);
  }
  
  await sharpInstance.toFile(enhancedImagePath);
  return enhancedImagePath;
}

async function enhanceImageWithAI(originalImagePath: string): Promise<string> {
  try {
    // Use environment variable for API key with fallback
    const apiKey = process.env.REPLICATE_API_TOKEN || process.env.REPLICATE_API_KEY || "";
    
    if (!apiKey) {
      throw new Error("Replicate API key not found in environment variables");
    }

    // Read the image file
    const imageBuffer = fs.readFileSync(originalImagePath);
    const base64Image = `data:image/jpeg;base64,${imageBuffer.toString('base64')}`;

    // Call Replicate API for image enhancement
    const response = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        "Authorization": `Token ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        version: "9283608cc6b7be6b65a8e44983db012355fde4132009bf99d976b2f0896856a3", // Real-ESRGAN model
        input: {
          image: base64Image,
          scale: 2,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Replicate API error: ${response.status} ${response.statusText}`);
    }

    const prediction = await response.json();
    
    // Poll for completion
    let result = prediction;
    while (result.status === "starting" || result.status === "processing") {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const statusResponse = await fetch(`https://api.replicate.com/v1/predictions/${result.id}`, {
        headers: {
          "Authorization": `Token ${apiKey}`,
        },
      });
      
      if (!statusResponse.ok) {
        throw new Error(`Failed to check prediction status: ${statusResponse.status}`);
      }
      
      result = await statusResponse.json();
    }

    if (result.status === "failed") {
      throw new Error(`Enhancement failed: ${result.error}`);
    }

    if (!result.output) {
      throw new Error("No enhanced image returned from API");
    }

    // Download the enhanced image
    const enhancedImageUrl = Array.isArray(result.output) ? result.output[0] : result.output;
    const enhancedResponse = await fetch(enhancedImageUrl);
    
    if (!enhancedResponse.ok) {
      throw new Error("Failed to download enhanced image");
    }

    const enhancedImageBuffer = await enhancedResponse.arrayBuffer();
    const enhancedImagePath = originalImagePath.replace("-processed.jpg", "-enhanced.jpg");
    
    fs.writeFileSync(enhancedImagePath, Buffer.from(enhancedImageBuffer));
    
    return enhancedImagePath;
  } catch (error) {
    console.error("AI enhancement failed:", error);
    
    // Fallback: create a mock enhanced version using Sharp
    const enhancedImagePath = originalImagePath.replace("-processed.jpg", "-enhanced.jpg");
    await sharp(originalImagePath)
      .sharpen()
      .modulate({ brightness: 1.1, saturation: 1.2 })
      .toFile(enhancedImagePath);
      
    return enhancedImagePath;
  }
}
