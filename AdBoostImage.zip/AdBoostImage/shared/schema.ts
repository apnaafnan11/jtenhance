import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const enhancements = pgTable("enhancements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalImagePath: text("original_image_path").notNull(),
  enhancedImagePath: text("enhanced_image_path"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  isPublic: boolean("is_public").default(true).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEnhancementSchema = createInsertSchema(enhancements).pick({
  originalImagePath: true,
  isPublic: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertEnhancement = z.infer<typeof insertEnhancementSchema>;
export type Enhancement = typeof enhancements.$inferSelect;
