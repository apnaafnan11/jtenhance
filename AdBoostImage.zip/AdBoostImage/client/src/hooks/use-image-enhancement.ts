import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Enhancement } from "@shared/schema";

export function useImageEnhancement() {
  const [enhancement, setEnhancement] = useState<Enhancement | null>(null);

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);
      
      const response = await apiRequest("POST", "/api/upload", formData);
      return response.json();
    },
    onSuccess: (data: Enhancement) => {
      setEnhancement(data);
    },
  });

  const enhanceMutation = useMutation({
    mutationFn: async ({ id, settings }: { id: string; settings?: any }) => {
      const response = await apiRequest("POST", `/api/enhance/${id}`, settings);
      return response.json();
    },
    onSuccess: (data: Enhancement) => {
      setEnhancement(data);
    },
  });

  // Poll for enhancement status if processing
  const { data: statusData } = useQuery<Enhancement>({
    queryKey: ["/api/enhancement", enhancement?.id],
    enabled: !!enhancement?.id && enhancement.status === "processing",
    refetchInterval: 2000,
  });

  // Update enhancement state when status changes
  if (statusData && enhancement && statusData.id === enhancement.id) {
    if (statusData.status !== enhancement.status) {
      setEnhancement(statusData as Enhancement);
    }
  }

  const uploadImage = async (file: File) => {
    uploadMutation.mutate(file);
  };

  const enhanceImage = async (id: string, settings?: any) => {
    enhanceMutation.mutate({ id, settings });
  };

  const downloadEnhanced = (imagePath: string) => {
    const link = document.createElement("a");
    link.href = `/uploads/${imagePath.split('/').pop()}`;
    link.download = `enhanced-${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return {
    enhancement,
    isUploading: uploadMutation.isPending,
    isEnhancing: enhanceMutation.isPending || enhancement?.status === "processing",
    error: uploadMutation.error?.message || enhanceMutation.error?.message || 
           (enhancement?.status === "failed" ? enhancement.errorMessage : null),
    uploadImage,
    enhanceImage,
    downloadEnhanced,
  };
}
