import { useState } from "react";
import { ImageEnhancer } from "@/components/image-enhancer";
import { AdMobBanner, AdMobInterstitial } from "@/components/admob-ads";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Zap, Clock, Shield, Image, Camera, Upload, Settings } from "lucide-react";

export default function Home() {
  const [showEnhancer, setShowEnhancer] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);

  const handleImageUpload = (file: File) => {
    setUploadedImage(file);
    setShowEnhancer(true);
  };

  const handleFileUpload = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleImageUpload(file);
      }
    };
    input.click();
  };

  const handleCameraCapture = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.capture = "environment";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleImageUpload(file);
      }
    };
    input.click();
  };

  if (showEnhancer && uploadedImage) {
    return (
      <ImageEnhancer 
        imageFile={uploadedImage} 
        onBack={() => {
          setShowEnhancer(false);
          setUploadedImage(null);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-xl">
      {/* Header */}
      <header className="gradient-bg text-white p-4 pb-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold" data-testid="app-title">JT Enhancer</h1>
          <Button 
            variant="ghost" 
            size="icon" 
            className="touch-target p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors text-white"
            data-testid="button-settings"
          >
            <Settings className="w-6 h-6" />
          </Button>
        </div>
        <p className="text-sm opacity-90">Transform your photos with AI-powered enhancement</p>
      </header>

      {/* AdMob Banner */}
      <div className="mx-4 mt-4">
        <AdMobBanner />
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 space-y-6">
        {/* Upload Section */}
        <section className="text-center">
          <div className="mb-6">
            <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
              <Image className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-2" data-testid="text-upload-title">Upload Your Photo</h2>
            <p className="text-muted-foreground">Choose a photo to enhance with AI technology</p>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={handleFileUpload}
              className="w-full bg-primary text-primary-foreground font-medium py-4 px-6 rounded-lg touch-target hover:bg-primary/90 transition-colors flex items-center justify-center gap-3"
              data-testid="button-upload-gallery"
            >
              <Upload className="w-5 h-5" />
              Upload from Gallery
            </Button>

            <Button
              onClick={handleCameraCapture}
              variant="secondary"
              className="w-full bg-secondary text-secondary-foreground font-medium py-4 px-6 rounded-lg touch-target hover:bg-secondary/80 transition-colors flex items-center justify-center gap-3"
              data-testid="button-take-photo"
            >
              <Camera className="w-5 h-5" />
              Take Photo
            </Button>
          </div>
        </section>

        {/* Feature Highlights */}
        <section className="grid grid-cols-2 gap-4">
          <Card className="bg-card border border-border rounded-lg p-4 text-center" data-testid="card-feature-ai">
            <div className="w-12 h-12 mx-auto mb-3 bg-accent/10 rounded-full flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-semibold text-sm mb-1">AI Enhancement</h3>
            <p className="text-xs text-muted-foreground">Advanced AI algorithms</p>
          </Card>

          <Card className="bg-card border border-border rounded-lg p-4 text-center" data-testid="card-feature-quality">
            <div className="w-12 h-12 mx-auto mb-3 bg-primary/10 rounded-full flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold text-sm mb-1">Quality Boost</h3>
            <p className="text-xs text-muted-foreground">Professional results</p>
          </Card>

          <Card className="bg-card border border-border rounded-lg p-4 text-center" data-testid="card-feature-speed">
            <div className="w-12 h-12 mx-auto mb-3 bg-blue-500/10 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-500" />
            </div>
            <h3 className="font-semibold text-sm mb-1">Fast Processing</h3>
            <p className="text-xs text-muted-foreground">Results in seconds</p>
          </Card>

          <Card className="bg-card border border-border rounded-lg p-4 text-center" data-testid="card-feature-secure">
            <div className="w-12 h-12 mx-auto mb-3 bg-purple-500/10 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-purple-500" />
            </div>
            <h3 className="font-semibold text-sm mb-1">Secure</h3>
            <p className="text-xs text-muted-foreground">Privacy protected</p>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="p-4 border-t border-border">
        <AdMobBanner />
        
        <div className="text-center text-xs text-muted-foreground mt-4">
          <p className="mb-2">Powered By JamberTech</p>
          <div className="flex justify-center space-x-4">
            <Button variant="ghost" size="sm" className="touch-target hover:text-primary transition-colors" data-testid="link-privacy">
              Privacy
            </Button>
            <Button variant="ghost" size="sm" className="touch-target hover:text-primary transition-colors" data-testid="link-terms">
              Terms
            </Button>
            <Button variant="ghost" size="sm" className="touch-target hover:text-primary transition-colors" data-testid="link-support">
              Support
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
}
