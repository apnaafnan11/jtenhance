import { useState } from "react";
import { Card } from "@/components/ui/card";

interface ImageComparisonProps {
  originalImageUrl: string;
  enhancedImageUrl?: string;
  isProcessing?: boolean;
}

export function ImageComparison({ originalImageUrl, enhancedImageUrl, isProcessing }: ImageComparisonProps) {
  const [sliderValue, setSliderValue] = useState(50);

  return (
    <div className="space-y-4">
      {/* Image Comparison Container */}
      <div className="comparison-slider bg-gray-100 rounded-xl overflow-hidden relative" style={{ height: "300px" }}>
        {/* Original Image */}
        <img
          src={originalImageUrl}
          alt="Original uploaded image"
          className="absolute inset-0 w-full h-full object-cover"
          data-testid="img-original"
        />

        {/* Enhanced Image */}
        {enhancedImageUrl && (
          <img
            src={enhancedImageUrl}
            alt="AI enhanced image"
            className="absolute inset-0 w-full h-full object-cover"
            style={{ clipPath: `inset(0 0 0 ${sliderValue}%)` }}
            data-testid="img-enhanced"
          />
        )}

        {/* Processing Overlay */}
        {isProcessing && (
          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
            <Card className="p-4 bg-white/90">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-primary rounded-full animate-pulse"></div>
                <span className="text-sm font-medium">Processing...</span>
              </div>
            </Card>
          </div>
        )}

        {/* Comparison Slider */}
        {enhancedImageUrl && !isProcessing && (
          <input
            type="range"
            min="0"
            max="100"
            value={sliderValue}
            onChange={(e) => setSliderValue(Number(e.target.value))}
            className="comparison-range absolute top-1/2 left-0 w-full transform -translate-y-1/2 z-10"
            data-testid="slider-comparison"
          />
        )}
      </div>

      {/* Labels */}
      <div className="flex justify-between text-sm text-muted-foreground">
        <span data-testid="text-original-label">Original</span>
        <span data-testid="text-enhanced-label">AI Enhanced</span>
      </div>
    </div>
  );
}
