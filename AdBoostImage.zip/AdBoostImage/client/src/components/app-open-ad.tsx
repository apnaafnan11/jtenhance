import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Sparkles } from "lucide-react";

export function AppOpenAd() {
  const [showAd, setShowAd] = useState(false);

  useEffect(() => {
    // Show app open ad when user first visits
    const hasSeenAppOpenAd = localStorage.getItem("hasSeenAppOpenAd");
    
    if (!hasSeenAppOpenAd) {
      // Load Google AdSense script for app open ad
      if (!document.querySelector('script[src*="adsbygoogle"]')) {
        const script = document.createElement('script');
        script.async = true;
        script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6102903821062048";
        script.crossOrigin = "anonymous";
        document.head.appendChild(script);
      }

      setTimeout(() => {
        setShowAd(true);
      }, 1000);
    }
  }, []);

  const handleCloseAd = () => {
    setShowAd(false);
    localStorage.setItem("hasSeenAppOpenAd", "true");
  };

  if (!showAd) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-sm bg-white relative">
        <Button
          onClick={handleCloseAd}
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 z-10"
          data-testid="button-close-app-open-ad"
        >
          <X className="w-4 h-4" />
        </Button>
        
        <div className="p-6 text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          
          <h2 className="text-xl font-bold mb-2">Welcome to JT Enhancer!</h2>
          <p className="text-muted-foreground mb-4">Transform your photos with AI-powered enhancement</p>
          
          {/* App Open Ad Placement */}
          <div 
            className="app-open-ad mb-4" 
            data-testid="app-open-ad"
            style={{ minHeight: "250px" }}
          >
            <ins 
              className="adsbygoogle"
              style={{ display: "block" }}
              data-ad-client="ca-pub-6102903821062048"
              data-ad-slot="2951401626"
              data-ad-format="auto"
              data-full-width-responsive="true"
            ></ins>
          </div>
          
          <Button 
            onClick={handleCloseAd}
            className="w-full bg-primary text-primary-foreground"
            data-testid="button-start-enhancing"
          >
            Start Enhancing Photos
          </Button>
        </div>
      </Card>
    </div>
  );
}