import { useState, useEffect } from "react";
import { useImageEnhancement } from "@/hooks/use-image-enhancement";
import { ImageComparison } from "./image-comparison";
import { AdMobBanner, AdMobInterstitial } from "./admob-ads";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Sparkles, Settings, Download } from "lucide-react";

interface ImageEnhancerProps {
  imageFile: File;
  onBack: () => void;
}

export function ImageEnhancer({ imageFile, onBack }: ImageEnhancerProps) {
  const [showInterstitial, setShowInterstitial] = useState(true);
  const [customSettings, setCustomSettings] = useState({
    brightness: 1.1,
    contrast: 1.0,
    saturation: 1.2,
    sharpening: true,
    noiseReduction: false
  });
  const [showCustomDialog, setShowCustomDialog] = useState(false);
  const {
    enhancement,
    isUploading,
    isEnhancing,
    error,
    uploadImage,
    enhanceImage,
    downloadEnhanced,
  } = useImageEnhancement();

  // Upload image on component mount
  useEffect(() => {
    if (!enhancement && !isUploading) {
      uploadImage(imageFile);
    }
  }, [imageFile]);

  const handleEnhance = async () => {
    if (enhancement?.id) {
      await enhanceImage(enhancement.id);
      setShowInterstitial(false);
    }
  };

  const handleDownload = () => {
    if (enhancement?.enhancedImagePath) {
      downloadEnhanced(enhancement.enhancedImagePath);
    }
  };

  const handleCustomEnhance = async () => {
    if (enhancement?.id) {
      await enhanceImage(enhancement.id, customSettings);
      setShowCustomDialog(false);
      setShowInterstitial(false);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-xl">
        <header className="gradient-bg text-white p-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="text-white hover:bg-white/20"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-xl font-bold">Error</h1>
          </div>
        </header>

        <main className="flex-1 p-4 flex items-center justify-center">
          <Card className="p-6 text-center max-w-sm">
            <h2 className="text-lg font-semibold mb-2 text-destructive">Enhancement Failed</h2>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Button onClick={onBack} data-testid="button-try-again">
              Try Another Image
            </Button>
          </Card>
        </main>
      </div>
    );
  }

  if (isUploading) {
    return (
      <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-xl">
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="p-8 mx-4 text-center max-w-sm w-full">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center loading-shimmer">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Uploading Image</h3>
            <p className="text-muted-foreground text-sm mb-4">Preparing your photo...</p>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-primary h-2 rounded-full transition-all duration-500 w-1/3"></div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  if (isEnhancing) {
    return (
      <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-xl">
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="p-8 mx-4 text-center max-w-sm w-full">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center loading-shimmer">
              <Sparkles className="w-8 h-8 text-white animate-pulse" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Enhancing Your Image</h3>
            <p className="text-muted-foreground text-sm mb-4">AI is working its magic...</p>
            <div className="w-full bg-muted rounded-full h-2 mb-4">
              <div className="bg-primary h-2 rounded-full transition-all duration-500 w-2/3"></div>
            </div>
            <p className="text-xs text-muted-foreground">This may take a few seconds</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-xl">
      {/* Header */}
      <header className="gradient-bg text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="text-white hover:bg-white/20"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-xl font-bold">JT Enhancer</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            data-testid="button-settings"
          >
            <Settings className="w-6 h-6" />
          </Button>
        </div>
      </header>

      {/* AdMob Interstitial */}
      {showInterstitial && <AdMobInterstitial />}

      <main className="flex-1 p-4 space-y-6">
        {enhancement && (
          <>
            <section>
              <h2 className="text-xl font-bold mb-4 text-center" data-testid="text-result-title">
                Enhancement Result
              </h2>

              {/* Image Comparison */}
              <ImageComparison
                originalImageUrl={`/uploads/${enhancement.originalImagePath.split('/').pop()}`}
                enhancedImageUrl={
                  enhancement.enhancedImagePath
                    ? `/uploads/${enhancement.enhancedImagePath.split('/').pop()}`
                    : undefined
                }
                isProcessing={enhancement.status === "processing"}
              />

              {/* Enhancement Options */}
              <div className="grid grid-cols-2 gap-3 mb-6 mt-6">
                <Button
                  onClick={handleEnhance}
                  disabled={enhancement.status === "processing" || enhancement.status === "completed"}
                  className="bg-primary text-primary-foreground py-3 px-4 rounded-lg font-medium touch-target transition-colors flex items-center justify-center gap-2"
                  data-testid="button-auto-enhance"
                >
                  <Sparkles className="w-5 h-5" />
                  {enhancement.status === "completed" ? "Enhanced" : "Auto Enhance"}
                </Button>

                <Dialog open={showCustomDialog} onOpenChange={setShowCustomDialog}>
                  <DialogTrigger asChild>
                    <Button
                      variant="secondary"
                      disabled={enhancement.status === "processing" || enhancement.status === "completed"}
                      className="bg-secondary text-secondary-foreground py-3 px-4 rounded-lg font-medium touch-target transition-colors flex items-center justify-center gap-2"
                      data-testid="button-custom-enhance"
                    >
                      <Settings className="w-5 h-5" />
                      Custom
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-4">
                    <DialogHeader>
                      <DialogTitle>Custom Enhancement Settings</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="brightness">Brightness: {customSettings.brightness.toFixed(1)}</Label>
                        <Slider
                          id="brightness"
                          min={0.5}
                          max={2.0}
                          step={0.1}
                          value={[customSettings.brightness]}
                          onValueChange={(value) => setCustomSettings(prev => ({ ...prev, brightness: value[0] }))}
                          data-testid="slider-brightness"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="contrast">Contrast: {customSettings.contrast.toFixed(1)}</Label>
                        <Slider
                          id="contrast"
                          min={0.5}
                          max={2.0}
                          step={0.1}
                          value={[customSettings.contrast]}
                          onValueChange={(value) => setCustomSettings(prev => ({ ...prev, contrast: value[0] }))}
                          data-testid="slider-contrast"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="saturation">Saturation: {customSettings.saturation.toFixed(1)}</Label>
                        <Slider
                          id="saturation"
                          min={0.0}
                          max={2.0}
                          step={0.1}
                          value={[customSettings.saturation]}
                          onValueChange={(value) => setCustomSettings(prev => ({ ...prev, saturation: value[0] }))}
                          data-testid="slider-saturation"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="sharpening">Sharpening</Label>
                        <Switch
                          id="sharpening"
                          checked={customSettings.sharpening}
                          onCheckedChange={(checked) => setCustomSettings(prev => ({ ...prev, sharpening: checked }))}
                          data-testid="switch-sharpening"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="noise-reduction">Noise Reduction</Label>
                        <Switch
                          id="noise-reduction"
                          checked={customSettings.noiseReduction}
                          onCheckedChange={(checked) => setCustomSettings(prev => ({ ...prev, noiseReduction: checked }))}
                          data-testid="switch-noise-reduction"
                        />
                      </div>
                      
                      <Button
                        onClick={handleCustomEnhance}
                        className="w-full bg-primary text-primary-foreground font-medium py-3 px-4 rounded-lg touch-target transition-colors flex items-center justify-center gap-2"
                        data-testid="button-apply-custom"
                      >
                        <Sparkles className="w-5 h-5" />
                        Apply Custom Enhancement
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Action Buttons */}
              {enhancement.status === "completed" && enhancement.enhancedImagePath && (
                <div className="space-y-3">
                  <Button
                    onClick={handleDownload}
                    className="w-full bg-accent text-accent-foreground font-semibold py-4 px-6 rounded-lg touch-target transition-colors flex items-center justify-center gap-3"
                    data-testid="button-download"
                  >
                    <Download className="w-5 h-5" />
                    Download Enhanced Image
                  </Button>

                  <Button
                    onClick={onBack}
                    variant="secondary"
                    className="w-full bg-secondary text-secondary-foreground font-medium py-3 px-6 rounded-lg touch-target transition-colors"
                    data-testid="button-enhance-another"
                  >
                    Enhance Another Photo
                  </Button>
                </div>
              )}
            </section>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="p-4 border-t border-border">
        <AdMobBanner />
      </footer>
    </div>
  );
}
