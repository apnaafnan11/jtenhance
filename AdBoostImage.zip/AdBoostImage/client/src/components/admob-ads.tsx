import { useEffect } from "react";

// Google AdSense Banner Component  
export function AdMobBanner() {
  useEffect(() => {
    // Load Google AdSense script
    if (!document.querySelector('script[src*="adsbygoogle"]')) {
      const script = document.createElement('script');
      script.async = true;
      script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6102903821062048";
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);
    }

    // Initialize AdSense ads
    try {
      if (window.adsbygoogle) {
        window.adsbygoogle.push({});
      }
    } catch (error) {
      console.log("AdSense not ready yet");
    }
  }, []);

  return (
    <div 
      className="adsense-banner rounded-lg" 
      data-testid="adsense-banner"
      style={{ minHeight: "50px" }}
    >
      <ins 
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client="ca-pub-6102903821062048"
        data-ad-slot="2951401626"
        data-ad-format="auto"
        data-full-width-responsive="true"
      ></ins>
    </div>
  );
}

// Google AdSense Large Ad Component
export function AdMobInterstitial() {
  useEffect(() => {
    // Load Google AdSense script if not already loaded
    if (!document.querySelector('script[src*="adsbygoogle"]')) {
      const script = document.createElement('script');
      script.async = true;
      script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6102903821062048";
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);
    }

    // Initialize AdSense ads
    try {
      if (window.adsbygoogle) {
        window.adsbygoogle.push({});
      }
    } catch (error) {
      console.log("AdSense not ready yet");
    }
  }, []);

  return (
    <div className="mx-4 mb-6">
      <div 
        className="adsense-large rounded-lg" 
        data-testid="adsense-large"
        style={{ minHeight: "300px" }}
      >
        <ins 
          className="adsbygoogle"
          style={{ display: "block" }}
          data-ad-client="ca-pub-6102903821062048"
          data-ad-slot="2951401626"
          data-ad-format="auto"
          data-full-width-responsive="true"
        ></ins>
      </div>
    </div>
  );
}

// Extend window object to include Google AdSense
declare global {
  interface Window {
    adsbygoogle?: any[];
  }
}
